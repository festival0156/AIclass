package encrypt;

import java.io.File;
import java.io.FileNotFoundException;

class Main {
    
    public static void main(String[] args) {
        String path = null;
        if (args.length == 0) {
            System.err.println("Unable to find directory. Sourcing from standard input.");
            System.out.println("Enter directory path:");
            path = new java.util.Scanner(System.in).nextLine();
        } else if (args.length!=1) {
            System.err.println("Invalid switch: " + args[1]);
            System.exit(1);
        } else {
            path = args[0];
        }
        EncFile files;
        try {
            files = new EncFile(path);
        } catch (FileNotFoundException exp) {
            System.out.print("Bad input. File not found.\n\n");
            exp.printStackTrace();
            System.exit(2);
        }
        ;
    }
    
}
