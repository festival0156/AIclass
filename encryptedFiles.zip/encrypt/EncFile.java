package encrypt;

import java.io.File;
import java.io.Serializable;
import java.io.FileNotFoundException;

import java.nio.file.Path; 
import java.nio.file.Paths; 

class EncFile extends File {

    EncFile[] files;

    EncFile(String pth) throws FileNotFoundException {
        super(pth);
        if (isFile())
            this.files = null;
        else if (isDirectory()) {
            File[] fs = listFiles();
            int len = fs.length;
            this.files = new EncFile[len];
            for (int i = 0; i<len; ++i)
                files[i] = new EncFile(fs[i].toString());
        } else
            throw new FileNotFoundException(toString() + " does not exist.");
    }

    private static String relativize(String pth, String ruts) {
        Path rut = Paths.get(ruts);//System.getProperty("user.dir")
        Path p = Paths.get(pth);
        System.out.println(rut + "\n" + p + "\n" + rut.relativize(p) + "\n");
        return rut.relativize(p).toString();
    }
    
}
