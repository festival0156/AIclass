package src;

import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;

import java.net.URI;
import java.net.InetSocketAddress;

import java.io.File;
import java.io.OutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.FileNotFoundException;

public class AssetHandler implements HttpHandler {

	public static final int port = 4321;
    
    public void handle(HttpExchange exg) throws IOException {
        if (!exg.getRequestMethod().equals("GET")) {
            exg.sendResponseHeaders(405, -1);
            return;
        }
        File path = new File(exg.getRequestURI());
        System.out.println(path);
        try (
            FileInputStream is = new FileInputStream(path);
        ) {
            byte[] bs = new byte[(int)path.length()];
            exg.sendResponseHeaders(200, bs.length);
            OutputStream out = exg.getResponseBody();
            is.read(bs);
            out.write(bs);
        } catch (FileNotFoundException exp) {
            exg.sendResponseHeaders(404, -1);
        }
        exg.close();
    }
    
    public static void main(String[] args) throws IOException {
    	InetSocketAddress con2 = new InetSocketAddress("localhost", port);
        HttpServer s = HttpServer.create(con2, 0);
        s.createContext("/assets", new AssetHandler());
        s.start();
        System.out.println("Server started @ " + con2);
    }
    
}
